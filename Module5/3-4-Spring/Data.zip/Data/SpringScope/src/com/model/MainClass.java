package com.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass 
{
	public static void main(String[] args)
	{
		
			ApplicationContext acm = new ClassPathXmlApplicationContext("beans.xml");
			Person per = (Person) acm.getBean("t1");
		
			
			Person per1 = (Person) acm.getBean("t1");
			per1.setId(102);
			per1.setName("Meet");
			
			System.out.println(per.id+" "+per.name);
			System.out.println(per1.id+" "+per1.name);
		
	}
}
