import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class MyServlet extends HttpServlet
{
	
	ServletContext context;
	ServletConfig config;
	String a,b;
	
	@Override
	public void init(ServletConfig config) throws ServletException 
	{
		// TODO Auto-generated method stub
		this.config=config;
		this.context=config.getServletContext();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		//super.doGet(req, resp);
	
		a = config.getInitParameter("driver");
		System.out.println(a);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		b = context.getInitParameter("host");
		System.out.println(b);
	
	}	
}
