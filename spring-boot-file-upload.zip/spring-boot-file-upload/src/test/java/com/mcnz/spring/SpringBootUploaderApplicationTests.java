package com.mcnz.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootUploaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
