package com.mcnz.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootUploaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootUploaderApplication.class, args);
	}

}
