package com.controller;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bo.Bo;
import com.model.Person;

public class MainClass 
{
	public static void main(String[] args) 
	{
		
		ApplicationContext acm = new ClassPathXmlApplicationContext("beans.xml");
		
//		Bo bo = (Bo) acm.getBean("bo");
//		Person p = (Person) acm.getBean("model");
		
		Bo bo = (Bo) acm.getBean("bo");
		Person p = (Person) acm.getBean("model");
				
				
				
		
		
		//Insert
//		
//		Scanner sc = new Scanner(System.in);
//		
//		System.out.println("Enter Your Name");
//		String name = sc.next();
//		
//		System.out.println("Enter Your Surname");
//		String surname = sc.next();
//		
//		p.setName(name);
//		p.setSurname(surname);
//	
//		bo.insert(p);
		
		
		//Update
		
		
//		Scanner sc = new Scanner(System.in);
//		
//		System.out.println("Enter Your Id");
//		int id = sc.nextInt();
//		
//		System.out.println("Enter Your Name");
//		String name = sc.next();
//		
//		System.out.println("Enter Your Surname");
//		String surname = sc.next();
//		
//	
//		p.setId(id);
//		p.setName(name);
//		p.setSurname(surname);
//	
//		bo.update(p);
		
		
		
		//Delete
		
//		Scanner sc = new Scanner(System.in);
//		
//		System.out.println("Enter Your Id");
//		int id = sc.nextInt();
//		
//		p.setId(id);
//		bo.delete(p);
//		
		
		//View
		
//		List<Person>list = bo.viewall();
//		
//		for(Person person : list)
//		{
//				System.out.println(person.getId()+"\t|\t"+person.getName()+"|\t"+person.getSurname());
//		}
		
		//Single Record
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Id");
		int id = sc.nextInt();
		p.setId(id);
		Person p1 = bo.getsingle(p);
		System.out.println(p1.getName());
		
		
	}
}
